package MenuTools;

public class IncompleteMenuException extends Exception{
    public IncompleteMenuException(String errorMessage) {
        super(errorMessage);
    }
}
