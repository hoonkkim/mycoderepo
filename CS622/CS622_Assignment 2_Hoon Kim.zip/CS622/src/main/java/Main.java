import java.io.IOException;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws IOException, IncompleteMenuException {
        // write your code here
        // let's set up some menus

        // In Release #1 all menus are hardcoded
        // Make a new array of Menus, then fill them with menu items.
        // This process will be parameterized in future releases.
        ArrayList<Menu> menuArrayList = new ArrayList<>();
        Menu OrangeChicken = new OrderedMenu("Orange Chicken", 13.95, 1
                , 2, "Uber Eats");
        menuArrayList.add(OrangeChicken);

        Menu PadThai = new OrderedMenu("Pad Thai", 14.99, 2
                , 1, "DoorDash");
        menuArrayList.add(PadThai);

        Menu ClubSandwich = new OrderedMenu("Club Sandwich", 10.50, 7
                , 0, "Uber Eats");
        menuArrayList.add(ClubSandwich);

        Menu Sushi = new OrderedMenu("Sushi", 24.00, 3
                , 0, "Grubhub");
        menuArrayList.add(Sushi);

        Menu KimchiFriedRice = new CookedMenu("Kimchi Fried Rice", 4.31
                , 8, 0, 4.2, 30);
        menuArrayList.add(KimchiFriedRice);

        // Importer Test
        menuFileImporter mfi = new menuFileImporter();
        ArrayList<Menu> inputMenuList = new ArrayList<Menu>();

        try {
            inputMenuList = mfi.fileToMenu("menuInputFile.txt");
        }
        catch (IncompleteMenuException e) {
            e.printStackTrace();
            System.exit(1);
        }

        menuArrayList.add(inputMenuList.get(0));
        menuArrayList.add(inputMenuList.get(1));

        // Instantiate a new MenuRecommender()
        menuRecommendationSorter Rec = new menuRecommendationSorter();
        menuPrinter mPrinter = new menuPrinter();
        // make a new array that is sorted by frequency descending with the menuArraySorter method
        // Showcase the Sorter by first showing the original array...
        System.out.println("These were the menus in the order they were entered:");
        mPrinter.printMenus(menuArrayList);


        ArrayList<Menu> sortedMenuArrayList = Rec.sortMenus(menuArrayList);
        // ... then show the array that's been sorted with frequency descending.
        System.out.println("These were the menus in the order they are Recommended:");
        mPrinter.printMenus(sortedMenuArrayList);

        // Instantiate menuRecommendationExporter()
        menuRecommendationExporter Exp = new menuRecommendationExporter();
        // Run menuRecommenationsExportFormatting() to return an array of Strings to export to file
        String[] ExportMenuStrings = Exp.menuToString(sortedMenuArrayList);
        //
        Exp.exportMenus(ExportMenuStrings);

    }
}
